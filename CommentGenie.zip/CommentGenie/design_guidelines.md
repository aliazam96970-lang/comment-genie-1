# YouTube Comment Sentiment Analysis Dashboard - Design Guidelines

## Design Approach: Analytics Dashboard System
**Selected Approach**: Design System - Modern Analytics Dashboard
**Justification**: This is a data-dense, utility-focused application where clarity, readability, and efficient information processing are paramount. Drawing inspiration from Linear's clean interface, Notion's organization, and modern analytics platforms.

**Key Design Principles**:
- Data clarity over decoration
- Hierarchical information architecture
- Scannable layouts with clear visual separation
- Purposeful use of color for data categorization

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary)**:
- Background: 220 15% 8% (deep slate)
- Surface: 220 13% 12% (elevated panels)
- Border: 220 10% 20% (subtle divisions)
- Text Primary: 220 10% 95%
- Text Secondary: 220 8% 65%

**Light Mode**:
- Background: 220 15% 98%
- Surface: 0 0% 100%
- Border: 220 13% 88%
- Text Primary: 220 15% 15%
- Text Secondary: 220 10% 45%

**Semantic Colors**:
- Positive Sentiment: 142 76% 45% (green)
- Negative Sentiment: 0 72% 55% (red)
- Neutral Sentiment: 45 93% 58% (amber)
- Primary Accent: 217 91% 60% (blue for CTAs)

### B. Typography

**Font Families**:
- Primary: 'Inter' (Google Fonts) - body, UI elements
- Monospace: 'JetBrains Mono' - data values, metrics

**Scale**:
- Hero/Dashboard Title: text-3xl font-bold (2rem)
- Section Headers: text-xl font-semibold (1.25rem)
- Card Titles: text-base font-medium
- Body Text: text-sm (0.875rem)
- Metrics/Numbers: text-2xl font-bold
- Labels: text-xs font-medium uppercase tracking-wide

### C. Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6, p-8
- Card spacing: gap-4, gap-6
- Section margins: mb-8, mb-12
- Container max-width: max-w-7xl

**Grid Structure**:
- Dashboard: 12-column grid
- Metrics row: grid-cols-2 md:grid-cols-4
- Charts: grid-cols-1 lg:grid-cols-2
- Comment feed: Single column with max-w-4xl

### D. Component Library

**Dashboard Layout**:
- Top Navigation: Fixed header with video input, filters, time range selector
- Sidebar: Video history, saved analyses (collapsible on mobile)
- Main Content: Metric cards → Charts → Comment list

**Metric Cards**:
- Elevated surface with border
- Large number display with trend indicator (↑↓)
- Label below in muted color
- Subtle background gradient for sentiment cards

**Charts & Visualizations**:
- Sentiment Distribution: Donut chart with color-coded segments
- Timeline: Line/area chart showing sentiment over time
- Word Cloud: Top keywords sized by frequency
- Use Chart.js or Recharts library via CDN

**Comment Cards**:
- Author avatar (YouTube profile pic or placeholder)
- Comment text with "Read more" for long content
- Sentiment badge (pill shape with color)
- Timestamp and engagement metrics (likes)
- Subtle hover effect (border color change)

**Data Table** (optional view):
- Sortable columns: Author, Comment, Sentiment, Date
- Alternating row colors for scannability
- Compact spacing (py-2)

**Input Components**:
- Video ID Input: Large, prominent with paste button
- Search Bar: Icon prefix, rounded corners
- Filters: Multi-select dropdowns or toggle chips
- Date Range: Calendar picker

**Loading States**:
- Skeleton screens matching card layouts
- Pulsing animation (animate-pulse)
- Spinner for inline actions

### E. Interactions & Animations

**Minimal Animation Strategy**:
- Card hover: Subtle border color transition (200ms)
- Button states: Scale(0.98) on active
- Chart transitions: 300ms ease-in-out on data update
- Page transitions: None (instant navigation)
- Tooltip: Fade in 150ms

**NO animations for**: 
- Dashboard load
- Metric updates
- List rendering

## Images

**Hero Section**: NO large hero image - Dashboard apps prioritize data visibility immediately.

**Supporting Images**:
- Empty State: Illustration when no video analyzed (centered, max-w-sm, muted colors)
- Avatar Placeholders: Generic user icons for comments without profile pics
- Error States: Simple warning icon, not decorative images

## Layout Specifications

**Dashboard Structure**:
1. **Header Bar** (h-16): Logo, video input, user menu
2. **Metrics Row** (py-8): 4 key metrics cards in grid
3. **Visualization Section** (py-6): 2-column chart layout
4. **Comments Section** (py-8): Scrollable feed with filters

**Responsive Breakpoints**:
- Mobile: Stack all components, collapsible sidebar
- Tablet (md:): 2-column charts, visible sidebar
- Desktop (lg:): Full 12-column grid, expanded components

**Critical UX Details**:
- Sticky header for persistent access to video input
- Virtual scrolling for comment lists (1000+ items)
- Export functionality (CSV/JSON) for analysis data
- Real-time sentiment calculation display
- Filter persistence in URL params