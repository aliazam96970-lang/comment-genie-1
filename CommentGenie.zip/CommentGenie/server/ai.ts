import OpenAI from "openai";
import { z } from "zod";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

interface CommentSentiment {
  sentiment: "positive" | "negative" | "neutral";
  keywords: string[];
}

interface BatchAnalysisResult {
  comments: Array<{ index: number; sentiment: "positive" | "negative" | "neutral" }>;
  topKeywords: Array<{ text: string; count: number }>;
}

// Schema for AI response validation
const aiResponseSchema = z.object({
  comments: z.array(z.object({
    index: z.number(),
    sentiment: z.enum(["positive", "negative", "neutral"]),
  })),
  topKeywords: z.array(z.object({
    text: z.string(),
    count: z.number(),
  })),
});

export async function analyzeSentimentBatch(comments: Array<{ text: string }>): Promise<BatchAnalysisResult> {
  const commentTexts = comments.map((c, i) => `${i}: ${c.text}`).join('\n\n');
  
  const prompt = `Analyze the sentiment of these YouTube comments and extract keywords. For each comment, determine if it's positive, negative, or neutral.

Comments:
${commentTexts}

Respond in JSON format with:
1. "comments": array of objects with "index" (number) and "sentiment" ("positive", "negative", or "neutral")
2. "topKeywords": array of the top 15 most frequently mentioned keywords across all comments, each with "text" and estimated "count"

Focus on meaningful keywords (nouns, adjectives, key phrases) that capture the main topics and emotions.`;

  try {
    // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "You are a sentiment analysis expert. Analyze comments accurately and extract meaningful keywords. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 4000,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from AI");
    }

    const parsed = JSON.parse(content);
    const validated = aiResponseSchema.parse(parsed);
    
    return validated as BatchAnalysisResult;
  } catch (error) {
    console.error("AI analysis error:", error);
    
    // Fallback: assign neutral sentiment to all comments
    return {
      comments: comments.map((_, index) => ({
        index,
        sentiment: "neutral" as const,
      })),
      topKeywords: [],
    };
  }
}
