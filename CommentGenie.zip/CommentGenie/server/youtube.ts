import { google } from 'googleapis';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=youtube',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('YouTube not connected');
  }
  return accessToken;
}

export async function getUncachableYouTubeClient() {
  const accessToken = await getAccessToken();
  
  // Create OAuth2 client with the access token
  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({
    access_token: accessToken,
  });
  
  return google.youtube({ version: 'v3', auth: oauth2Client });
}

export async function fetchVideoComments(videoId: string, maxResults: number = 100) {
  const youtube = await getUncachableYouTubeClient();
  
  const response = await youtube.commentThreads.list({
    part: ['snippet'],
    videoId: videoId,
    maxResults: maxResults,
    order: 'relevance',
  });

  const comments = response.data.items?.map((item: any) => {
    const snippet = item.snippet.topLevelComment.snippet;
    return {
      author: snippet.authorDisplayName,
      authorAvatar: snippet.authorProfileImageUrl,
      text: snippet.textDisplay.replace(/<[^>]*>/g, ''), // Strip HTML tags
      publishedAt: new Date(snippet.publishedAt),
      likes: snippet.likeCount || 0,
    };
  }) || [];

  return comments;
}

export async function getVideoInfo(videoId: string) {
  const youtube = await getUncachableYouTubeClient();
  
  const response = await youtube.videos.list({
    part: ['snippet'],
    id: [videoId],
  });

  const video = response.data.items?.[0];
  if (!video) {
    throw new Error('Video not found');
  }

  return {
    title: video.snippet?.title || '',
  };
}
