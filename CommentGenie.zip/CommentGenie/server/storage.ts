import { 
  type Video, 
  type Comment, 
  type Keyword,
  type InsertVideo, 
  type InsertComment, 
  type InsertKeyword 
} from "@shared/schema";

export interface IStorage {
  // Videos
  getVideo(id: string): Promise<Video | undefined>;
  getVideoByVideoId(videoId: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  
  // Comments
  getCommentsByVideoId(videoId: string): Promise<Comment[]>;
  createComments(comments: InsertComment[]): Promise<Comment[]>;
  
  // Keywords
  getKeywordsByVideoId(videoId: string): Promise<Keyword[]>;
  createKeywords(keywords: InsertKeyword[]): Promise<Keyword[]>;
}

export class MemStorage implements IStorage {
  private videos: Map<string, Video>;
  private comments: Map<string, Comment>;
  private keywords: Map<string, Keyword>;

  constructor() {
    this.videos = new Map();
    this.comments = new Map();
    this.keywords = new Map();
  }

  async getVideo(id: string): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async getVideoByVideoId(videoId: string): Promise<Video | undefined> {
    return Array.from(this.videos.values()).find(v => v.videoId === videoId);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = insertVideo.videoId;
    const video: Video = { 
      id,
      videoId: insertVideo.videoId,
      title: insertVideo.title ?? null,
      analyzedAt: new Date() 
    };
    this.videos.set(id, video);
    return video;
  }

  async getCommentsByVideoId(videoId: string): Promise<Comment[]> {
    return Array.from(this.comments.values()).filter(c => c.videoId === videoId);
  }

  async createComments(insertComments: InsertComment[]): Promise<Comment[]> {
    const comments: Comment[] = insertComments.map(c => ({
      id: crypto.randomUUID(),
      videoId: c.videoId,
      author: c.author,
      authorAvatar: c.authorAvatar ?? null,
      text: c.text,
      sentiment: c.sentiment,
      publishedAt: c.publishedAt,
      likes: c.likes ?? null,
    }));
    comments.forEach(c => this.comments.set(c.id, c));
    return comments;
  }

  async getKeywordsByVideoId(videoId: string): Promise<Keyword[]> {
    return Array.from(this.keywords.values()).filter(k => k.videoId === videoId);
  }

  async createKeywords(insertKeywords: InsertKeyword[]): Promise<Keyword[]> {
    const keywords: Keyword[] = insertKeywords.map(k => ({
      id: crypto.randomUUID(),
      ...k,
    }));
    keywords.forEach(k => this.keywords.set(k.id, k));
    return keywords;
  }
}

export const storage = new MemStorage();
