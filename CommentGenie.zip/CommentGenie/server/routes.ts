import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { fetchVideoComments, getVideoInfo } from "./youtube";
import { analyzeSentimentBatch } from "./ai";
import { z } from "zod";

const analyzeRequestSchema = z.object({
  videoId: z.string().min(1, "Video ID is required"),
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Debug Route: Server health check
  app.get("/test", (req, res) => {
    res.send("✅ Backend updated — " + new Date().toLocaleString());
  });

  // Debug Route: YouTube API test
  app.get("/test-youtube", async (req, res) => {
    try {
      const videoId = "dQw4w9WgXcQ"; // test video
      const API_KEY = process.env.YOUTUBE_API_KEY;
      
      if (!API_KEY) {
        return res.json({
          message: "⚠️ Using YouTube OAuth connector (no API key needed)",
          note: "Current app uses OAuth authentication"
        });
      }

      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=${videoId}&maxResults=2&key=${API_KEY}`
      );
      const data = await response.json();

      res.json({
        message: "✅ YouTube API working!",
        commentsFetched: data.items ? data.items.length : 0,
        firstComment:
          data.items?.[0]?.snippet?.topLevelComment?.snippet?.textDisplay || "No comment found"
      });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // Debug Route: Supabase test
  app.get("/test-supabase", async (req, res) => {
    try {
      if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
        return res.json({
          message: "⚠️ Using in-memory storage (no Supabase configured)",
          note: "Current app uses MemStorage for development"
        });
      }

      // Dynamically import Supabase if configured
      const { createClient } = await import("@supabase/supabase-js").catch(() => {
        throw new Error("Supabase package not installed");
      });

      const supabase = createClient(
        process.env.SUPABASE_URL!,
        process.env.SUPABASE_SERVICE_KEY!
      );

      const { data, error } = await supabase.from("comment").select("*").limit(1);
      if (error) throw error;

      res.json({
        message: "✅ Supabase connected!",
        sampleData: data || []
      });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });
  
  // Analyze a YouTube video
  app.post("/api/analyze", async (req, res) => {
    try {
      // Validate request body
      const validation = analyzeRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid request", 
          details: validation.error.issues 
        });
      }
      
      const { videoId } = validation.data;

      // Check if already analyzed
      const existing = await storage.getVideoByVideoId(videoId);
      if (existing) {
        const comments = await storage.getCommentsByVideoId(existing.id);
        const keywords = await storage.getKeywordsByVideoId(existing.id);
        
        return res.json({
          video: existing,
          comments,
          keywords,
        });
      }

      // Fetch video info
      const videoInfo = await getVideoInfo(videoId);
      
      // Fetch comments from YouTube
      const youtubeComments = await fetchVideoComments(videoId, 100);
      
      if (youtubeComments.length === 0) {
        return res.status(400).json({ error: "No comments found for this video" });
      }

      // Analyze sentiment using AI
      const analysis = await analyzeSentimentBatch(youtubeComments);
      
      // Create video record
      const video = await storage.createVideo({
        videoId,
        title: videoInfo.title,
      });

      // Store comments with sentiment
      const commentsToStore = youtubeComments.map((comment, index) => {
        const sentimentData = analysis.comments.find(c => c.index === index);
        return {
          videoId: video.id,
          author: comment.author,
          authorAvatar: comment.authorAvatar,
          text: comment.text,
          sentiment: sentimentData?.sentiment || "neutral",
          publishedAt: comment.publishedAt,
          likes: comment.likes,
        };
      });

      const comments = await storage.createComments(commentsToStore);

      // Store keywords
      const keywordsToStore = analysis.topKeywords.map(kw => ({
        videoId: video.id,
        text: kw.text,
        count: kw.count,
      }));

      const keywords = await storage.createKeywords(keywordsToStore);

      res.json({
        video,
        comments,
        keywords,
      });
    } catch (error: any) {
      console.error("Analysis error:", error);
      res.status(500).json({ 
        error: "Failed to analyze video", 
        details: error.message 
      });
    }
  });

  // Get analysis for a video
  app.get("/api/analysis/:videoId", async (req, res) => {
    try {
      const { videoId } = req.params;
      
      const video = await storage.getVideoByVideoId(videoId);
      if (!video) {
        return res.status(404).json({ error: "Video not analyzed yet" });
      }

      const comments = await storage.getCommentsByVideoId(video.id);
      const keywords = await storage.getKeywordsByVideoId(video.id);

      res.json({
        video,
        comments,
        keywords,
      });
    } catch (error: any) {
      console.error("Get analysis error:", error);
      res.status(500).json({ 
        error: "Failed to get analysis", 
        details: error.message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
