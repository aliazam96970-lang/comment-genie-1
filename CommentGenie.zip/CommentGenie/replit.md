# YouTube Comment Sentiment Analysis Dashboard

## Overview

This is a YouTube Comment Sentiment Analysis Dashboard that fetches comments from YouTube videos, analyzes their sentiment using AI, and presents interactive visualizations and insights. The application allows users to enter a YouTube video ID or URL, then displays sentiment distribution, trending keywords, and detailed comment analysis with positive, negative, and neutral classifications.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool

**UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling

**State Management**: TanStack Query (React Query) for server state management and data fetching

**Routing**: Wouter for lightweight client-side routing

**Design System**: 
- Modern analytics dashboard approach inspired by Linear's clean interface
- Custom theme system with dark/light modes
- Color-coded sentiment visualization (green for positive, red for negative, amber for neutral)
- Typography using Inter for UI elements and JetBrains Mono for data/metrics

**Key Components**:
- Dashboard page as the main entry point
- Reusable UI components for metrics, charts, comments, and keywords
- Real-time theme switching with localStorage persistence
- Responsive design optimized for data-dense displays

### Backend Architecture

**Runtime**: Node.js with Express.js web framework

**API Design**: RESTful endpoints with JSON responses

**Data Flow**:
1. Client submits video ID to `/api/analyze` endpoint
2. Server checks for existing analysis in storage
3. If new, fetches video metadata and comments from YouTube
4. Sends comments to AI service for sentiment analysis and keyword extraction
5. Stores results and returns aggregated data to client

**AI Integration**: OpenAI-compatible API (via Replit AI Integrations) for batch sentiment analysis using GPT-5-mini model

**Storage Strategy**: 
- Abstracted storage interface (`IStorage`) supporting both in-memory and database implementations
- In-memory storage (`MemStorage`) for development/testing
- Designed to support PostgreSQL via Drizzle ORM for production

### Data Storage

**ORM**: Drizzle ORM with PostgreSQL dialect

**Database Schema**:
- `videos` table: Stores video metadata (id, videoId, title, analyzedAt)
- `comments` table: Individual comments with sentiment, author info, and engagement metrics (likes)
- `keywords` table: Extracted keywords with occurrence counts per video

**Schema Features**:
- Type-safe schema definitions using Drizzle with Zod validation
- UUID primary keys for comments and keywords
- Foreign key relationships linking comments/keywords to videos
- Timestamps for analysis tracking

### External Dependencies

**YouTube Integration**: 
- Google APIs Node.js client for YouTube Data API v3
- OAuth2 authentication via Replit Connectors system
- Fetches video metadata and comment threads

**AI Service**: 
- Replit AI Integrations providing OpenAI-compatible API
- Uses environment variables for base URL and API key
- Structured JSON responses validated with Zod schemas
- Batch processing of comments for efficiency

**Third-party Libraries**:
- Recharts for data visualization (pie charts, line charts)
- date-fns for timestamp formatting
- Radix UI for accessible component primitives
- Tailwind CSS for utility-first styling

**Development Tools**:
- TypeScript for type safety across frontend and backend
- Vite plugins for development experience (error overlay, dev banner, cartographer)
- ESBuild for production server bundling

**Authentication & Session Management**:
- Uses Replit's identity system (REPL_IDENTITY) for connector authentication
- Structured to support session management via connect-pg-simple (PostgreSQL session store)