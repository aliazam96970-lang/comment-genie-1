import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const videos = pgTable("videos", {
  id: varchar("id").primaryKey(),
  videoId: varchar("video_id").notNull().unique(),
  title: text("title"),
  analyzedAt: timestamp("analyzed_at").defaultNow().notNull(),
});

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull().references(() => videos.id),
  author: text("author").notNull(),
  authorAvatar: text("author_avatar"),
  text: text("text").notNull(),
  sentiment: varchar("sentiment", { length: 20 }).notNull(),
  publishedAt: timestamp("published_at").notNull(),
  likes: integer("likes").default(0),
});

export const keywords = pgTable("keywords", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull().references(() => videos.id),
  text: text("text").notNull(),
  count: integer("count").notNull(),
});

export const insertVideoSchema = createInsertSchema(videos).omit({ id: true, analyzedAt: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true });
export const insertKeywordSchema = createInsertSchema(keywords).omit({ id: true });

export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type InsertKeyword = z.infer<typeof insertKeywordSchema>;

export type Video = typeof videos.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Keyword = typeof keywords.$inferSelect;
