import { Card } from "@/components/ui/card";
import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: {
    direction: "up" | "down";
    value: string;
  };
  sentiment?: "positive" | "negative" | "neutral";
}

export function MetricCard({ title, value, icon: Icon, trend, sentiment }: MetricCardProps) {
  const getSentimentColor = () => {
    if (!sentiment) return "";
    switch (sentiment) {
      case "positive":
        return "text-chart-1";
      case "negative":
        return "text-chart-2";
      case "neutral":
        return "text-chart-3";
      default:
        return "";
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="space-y-2 flex-1">
          <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            {title}
          </p>
          <div className="flex items-baseline gap-2">
            <p className={`text-2xl font-bold font-mono ${getSentimentColor()}`} data-testid={`metric-${title.toLowerCase().replace(/\s+/g, "-")}`}>
              {value}
            </p>
            {trend && (
              <div className={`flex items-center text-xs ${trend.direction === "up" ? "text-chart-1" : "text-chart-2"}`}>
                {trend.direction === "up" ? (
                  <TrendingUp className="h-3 w-3 mr-1" />
                ) : (
                  <TrendingDown className="h-3 w-3 mr-1" />
                )}
                {trend.value}
              </div>
            )}
          </div>
        </div>
        <div className={`p-2 rounded-md bg-muted ${getSentimentColor()}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}
