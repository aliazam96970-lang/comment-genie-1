import { useState } from "react";
import { Search, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface VideoInputProps {
  onAnalyze: (videoId: string) => void;
  isLoading?: boolean;
}

export function VideoInput({ onAnalyze, isLoading = false }: VideoInputProps) {
  const [videoInput, setVideoInput] = useState("");

  const extractVideoId = (input: string): string | null => {
    const trimmed = input.trim();
    
    if (trimmed.length === 11) {
      return trimmed;
    }
    
    const urlPatterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    ];
    
    for (const pattern of urlPatterns) {
      const match = trimmed.match(pattern);
      if (match) return match[1];
    }
    
    return null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const videoId = extractVideoId(videoInput);
    if (videoId) {
      onAnalyze(videoId);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 w-full max-w-2xl">
      <div className="relative flex-1">
        <Youtube className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Enter YouTube video ID or URL..."
          value={videoInput}
          onChange={(e) => setVideoInput(e.target.value)}
          className="pl-10"
          data-testid="input-video-id"
          disabled={isLoading}
        />
      </div>
      <Button 
        type="submit" 
        disabled={!videoInput.trim() || isLoading}
        data-testid="button-analyze"
      >
        <Search className="h-4 w-4 mr-2" />
        Analyze
      </Button>
    </form>
  );
}
