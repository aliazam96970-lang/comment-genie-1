import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Keyword {
  text: string;
  count: number;
}

interface KeywordCloudProps {
  keywords: Keyword[];
}

export function KeywordCloud({ keywords }: KeywordCloudProps) {
  const maxCount = Math.max(...keywords.map((k) => k.count));
  const minCount = Math.min(...keywords.map((k) => k.count));

  const getSize = (count: number) => {
    const normalized = (count - minCount) / (maxCount - minCount || 1);
    if (normalized > 0.7) return "lg";
    if (normalized > 0.4) return "default";
    return "sm";
  };

  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Top Keywords</h3>
      <div className="flex flex-wrap gap-2">
        {keywords.map((keyword, index) => (
          <Badge
            key={index}
            variant="outline"
            className="hover-elevate cursor-pointer"
            data-testid={`keyword-${keyword.text}`}
          >
            {keyword.text} ({keyword.count})
          </Badge>
        ))}
      </div>
    </Card>
  );
}
