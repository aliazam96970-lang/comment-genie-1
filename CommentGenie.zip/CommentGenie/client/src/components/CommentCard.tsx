import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThumbsUp } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface CommentCardProps {
  author: string;
  authorAvatar?: string;
  text: string;
  sentiment: "positive" | "negative" | "neutral";
  publishedAt: string;
  likes?: number;
}

export function CommentCard({
  author,
  authorAvatar,
  text,
  sentiment,
  publishedAt,
  likes = 0,
}: CommentCardProps) {
  const getSentimentVariant = () => {
    switch (sentiment) {
      case "positive":
        return "default";
      case "negative":
        return "destructive";
      case "neutral":
        return "secondary";
    }
  };

  const getSentimentLabel = () => {
    return sentiment.charAt(0).toUpperCase() + sentiment.slice(1);
  };

  return (
    <Card className="p-4 hover-elevate" data-testid={`comment-card-${author}`}>
      <div className="flex gap-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={authorAvatar} alt={author} />
          <AvatarFallback>{author.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <p className="font-medium text-sm" data-testid={`text-author-${author}`}>{author}</p>
              <p className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(publishedAt), { addSuffix: true })}
              </p>
            </div>
            <Badge variant={getSentimentVariant()} className="whitespace-nowrap" data-testid={`badge-sentiment-${sentiment}`}>
              {getSentimentLabel()}
            </Badge>
          </div>
          <p className="text-sm leading-relaxed" data-testid={`text-comment-${author}`}>{text}</p>
          {likes > 0 && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <ThumbsUp className="h-3 w-3" />
              <span>{likes.toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
