import { MetricCard } from "../MetricCard";
import { MessageSquare, ThumbsUp, ThumbsDown, Minus } from "lucide-react";

export default function MetricCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <MetricCard
        title="Total Comments"
        value="1,247"
        icon={MessageSquare}
        trend={{ direction: "up", value: "+12%" }}
      />
      <MetricCard
        title="Positive"
        value="68%"
        icon={ThumbsUp}
        sentiment="positive"
        trend={{ direction: "up", value: "+5%" }}
      />
      <MetricCard
        title="Negative"
        value="18%"
        icon={ThumbsDown}
        sentiment="negative"
        trend={{ direction: "down", value: "-3%" }}
      />
      <MetricCard
        title="Neutral"
        value="14%"
        icon={Minus}
        sentiment="neutral"
      />
    </div>
  );
}
