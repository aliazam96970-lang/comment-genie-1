import { CommentCard } from "../CommentCard";

export default function CommentCardExample() {
  return (
    <div className="space-y-4 max-w-3xl">
      <CommentCard
        author="Sarah Johnson"
        text="This is absolutely amazing! The quality of this content keeps getting better and better. Can't wait for the next one!"
        sentiment="positive"
        publishedAt={new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()}
        likes={142}
      />
      <CommentCard
        author="Mike Chen"
        text="I'm disappointed with this one. Expected much more based on the previous videos."
        sentiment="negative"
        publishedAt={new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString()}
        likes={23}
      />
      <CommentCard
        author="Alex Rivera"
        text="Thanks for sharing this. It's informative and well-presented."
        sentiment="neutral"
        publishedAt={new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()}
        likes={67}
      />
    </div>
  );
}
