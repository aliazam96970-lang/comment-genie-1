import { KeywordCloud } from "../KeywordCloud";

export default function KeywordCloudExample() {
  const mockKeywords = [
    { text: "amazing", count: 145 },
    { text: "great", count: 128 },
    { text: "love", count: 112 },
    { text: "helpful", count: 98 },
    { text: "thanks", count: 87 },
    { text: "awesome", count: 76 },
    { text: "perfect", count: 65 },
    { text: "excellent", count: 54 },
    { text: "informative", count: 43 },
    { text: "quality", count: 38 },
  ];

  return <KeywordCloud keywords={mockKeywords} />;
}
