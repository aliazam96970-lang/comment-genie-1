import { LoadingState } from "../LoadingState";

export default function LoadingStateExample() {
  return <LoadingState />;
}
