import { SentimentChart } from "../SentimentChart";

export default function SentimentChartExample() {
  return (
    <SentimentChart
      data={{
        positive: 847,
        negative: 224,
        neutral: 176,
      }}
    />
  );
}
