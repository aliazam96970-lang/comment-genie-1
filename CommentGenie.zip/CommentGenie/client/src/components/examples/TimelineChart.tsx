import { TimelineChart } from "../TimelineChart";

export default function TimelineChartExample() {
  const mockData = [
    { date: "Jan 1", positive: 45, negative: 12, neutral: 8 },
    { date: "Jan 8", positive: 52, negative: 15, neutral: 10 },
    { date: "Jan 15", positive: 68, negative: 18, neutral: 14 },
    { date: "Jan 22", positive: 71, negative: 16, neutral: 12 },
    { date: "Jan 29", positive: 85, negative: 22, neutral: 18 },
    { date: "Feb 5", positive: 92, negative: 20, neutral: 15 },
  ];

  return <TimelineChart data={mockData} />;
}
