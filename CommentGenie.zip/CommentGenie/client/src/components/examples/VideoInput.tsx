import { VideoInput } from "../VideoInput";

export default function VideoInputExample() {
  return (
    <VideoInput 
      onAnalyze={(videoId) => console.log("Analyzing video:", videoId)} 
    />
  );
}
