import { Card } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface TimelineDataPoint {
  date: string;
  positive: number;
  negative: number;
  neutral: number;
}

interface TimelineChartProps {
  data: TimelineDataPoint[];
}

export function TimelineChart({ data }: TimelineChartProps) {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Sentiment Over Time</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
          <YAxis stroke="hsl(var(--muted-foreground))" />
          <Tooltip
            contentStyle={{
              backgroundColor: "hsl(var(--popover))",
              border: "1px solid hsl(var(--border))",
              borderRadius: "var(--radius)",
            }}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="positive"
            stroke="hsl(var(--chart-1))"
            strokeWidth={2}
            name="Positive"
          />
          <Line
            type="monotone"
            dataKey="negative"
            stroke="hsl(var(--chart-2))"
            strokeWidth={2}
            name="Negative"
          />
          <Line
            type="monotone"
            dataKey="neutral"
            stroke="hsl(var(--chart-3))"
            strokeWidth={2}
            name="Neutral"
          />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}
