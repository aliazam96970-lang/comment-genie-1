import { Youtube } from "lucide-react";

export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="p-4 bg-muted rounded-full mb-4">
        <Youtube className="h-12 w-12 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">No Video Analyzed Yet</h3>
      <p className="text-muted-foreground max-w-md">
        Enter a YouTube video ID or URL above to analyze sentiment and extract insights from the comments.
      </p>
    </div>
  );
}
