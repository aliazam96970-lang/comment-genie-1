import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { VideoInput } from "@/components/VideoInput";
import { MetricCard } from "@/components/MetricCard";
import { SentimentChart } from "@/components/SentimentChart";
import { TimelineChart } from "@/components/TimelineChart";
import { CommentCard } from "@/components/CommentCard";
import { KeywordCloud } from "@/components/KeywordCloud";
import { EmptyState } from "@/components/EmptyState";
import { LoadingState } from "@/components/LoadingState";
import { ThemeToggle } from "@/components/ThemeToggle";
import { MessageSquare, ThumbsUp, ThumbsDown, Minus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AnalysisResponse {
  video: {
    id: string;
    videoId: string;
    title: string | null;
    analyzedAt: Date;
  };
  comments: Array<{
    id: string;
    videoId: string;
    author: string;
    authorAvatar: string | null;
    text: string;
    sentiment: string;
    publishedAt: Date;
    likes: number | null;
  }>;
  keywords: Array<{
    id: string;
    videoId: string;
    text: string;
    count: number;
  }>;
}

export default function Dashboard() {
  const [currentVideoId, setCurrentVideoId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: analysis, isLoading } = useQuery<AnalysisResponse>({
    queryKey: ["/api/analysis", currentVideoId],
    enabled: !!currentVideoId,
  });

  const analyzeMutation = useMutation({
    mutationFn: async (videoId: string) => {
      const response = await fetch("/api/analyze", {
        method: "POST",
        body: JSON.stringify({ videoId }),
        headers: { "Content-Type": "application/json" },
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to analyze video");
      }
      
      return response.json() as Promise<AnalysisResponse>;
    },
    onSuccess: (data: AnalysisResponse) => {
      setCurrentVideoId(data.video.videoId);
      queryClient.setQueryData(["/api/analysis", data.video.videoId], data);
      toast({
        title: "Analysis Complete",
        description: `Successfully analyzed ${data.comments.length} comments`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = (videoId: string) => {
    analyzeMutation.mutate(videoId);
  };

  const filteredComments = analysis?.comments.filter(comment =>
    comment.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
    comment.author.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const metrics = analysis?.comments.reduce(
    (acc, comment) => {
      acc.total++;
      if (comment.sentiment === "positive") acc.positive++;
      else if (comment.sentiment === "negative") acc.negative++;
      else acc.neutral++;
      return acc;
    },
    { total: 0, positive: 0, negative: 0, neutral: 0 }
  ) || { total: 0, positive: 0, negative: 0, neutral: 0 };

  const positivePercentage = metrics.total > 0 ? ((metrics.positive / metrics.total) * 100).toFixed(0) : "0";
  const negativePercentage = metrics.total > 0 ? ((metrics.negative / metrics.total) * 100).toFixed(0) : "0";
  const neutralPercentage = metrics.total > 0 ? ((metrics.neutral / metrics.total) * 100).toFixed(0) : "0";

  // Generate timeline data from comments
  const timelineData = analysis?.comments.reduce((acc: any[], comment) => {
    const date = new Date(comment.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const existing = acc.find(d => d.date === date);
    
    if (existing) {
      if (comment.sentiment === "positive") existing.positive++;
      else if (comment.sentiment === "negative") existing.negative++;
      else existing.neutral++;
    } else {
      acc.push({
        date,
        positive: comment.sentiment === "positive" ? 1 : 0,
        negative: comment.sentiment === "negative" ? 1 : 0,
        neutral: comment.sentiment === "neutral" ? 1 : 0,
      });
    }
    
    return acc;
  }, []).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).slice(-10) || [];

  const showLoading = analyzeMutation.isPending || isLoading;
  const hasAnalyzed = !!analysis;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4 mb-4">
            <h1 className="text-2xl font-bold">YouTube Sentiment Analysis</h1>
            <ThemeToggle />
          </div>
          <div className="flex justify-center">
            <VideoInput onAnalyze={handleAnalyze} isLoading={showLoading} />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {showLoading ? (
          <LoadingState />
        ) : !hasAnalyzed ? (
          <EmptyState />
        ) : (
          <div className="space-y-8">
            {analysis.video.title && (
              <div className="text-center">
                <h2 className="text-xl font-semibold text-muted-foreground">{analysis.video.title}</h2>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <MetricCard
                title="Total Comments"
                value={metrics.total.toLocaleString()}
                icon={MessageSquare}
              />
              <MetricCard
                title="Positive"
                value={`${positivePercentage}%`}
                icon={ThumbsUp}
                sentiment="positive"
              />
              <MetricCard
                title="Negative"
                value={`${negativePercentage}%`}
                icon={ThumbsDown}
                sentiment="negative"
              />
              <MetricCard
                title="Neutral"
                value={`${neutralPercentage}%`}
                icon={Minus}
                sentiment="neutral"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <SentimentChart data={metrics} />
              {timelineData.length > 0 && <TimelineChart data={timelineData} />}
            </div>

            {analysis.keywords.length > 0 && (
              <KeywordCloud keywords={analysis.keywords} />
            )}

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-semibold">Comments</h2>
                <div className="relative w-full max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search comments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-comments"
                  />
                </div>
              </div>
              
              <div className="space-y-3">
                {filteredComments.map((comment) => (
                  <CommentCard
                    key={comment.id}
                    author={comment.author}
                    authorAvatar={comment.authorAvatar || undefined}
                    text={comment.text}
                    sentiment={comment.sentiment as "positive" | "negative" | "neutral"}
                    publishedAt={comment.publishedAt.toString()}
                    likes={comment.likes || 0}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
