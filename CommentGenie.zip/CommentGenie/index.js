// index.js
const express = require("express");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static("public")); // serve index.html

// --- Server "version" to detect restarts (used by client to auto-reload) ---
const serverStartAt = new Date().toISOString();
let serverVersion = serverStartAt;

// Simple in-memory cache as fallback
const memoryCache = new Map(); // key = videoId, value = { fetchedAt, comments, analysis }

// Supabase client (optional)
let supabase = null;
(async () => {
  try {
    if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
      const { createClient } = await import("@supabase/supabase-js");
      supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
      console.log("✅ Supabase client initialized.");
    } else {
      console.log("ℹ️ Supabase not configured (SUPABASE_URL / SUPABASE_SERVICE_KEY missing). Using in-memory cache only.");
    }
  } catch (err) {
    console.error("❌ Supabase init failed:", err.message);
    supabase = null;
  }
})();

// Utility: sleep
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Utility: fetch with retries
async function fetchWithRetries(url, options = {}, retries = 2) {
  let attempt = 0;
  let lastErr = null;
  while (attempt <= retries) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} - ${text}`);
      }
      return await res.json();
    } catch (err) {
      lastErr = err;
      attempt++;
      if (attempt <= retries) {
        await sleep(500 * attempt);
      }
    }
  }
  throw lastErr;
}

// Simple sentiment classifier (easy to extend)
const positiveWords = ["good", "nice", "great", "love", "awesome", "best", "amazing", "cool"];
const negativeWords = ["bad", "hate", "worst", "poor", "angry", "terrible", "awful", "dislike"];

function analyzeComments(comments) {
  const analysis = { positive: 0, negative: 0, question: 0 };
  for (const c of comments) {
    const t = (c.text || "").toLowerCase();
    if (t.includes("?")) {
      analysis.question++;
    } else if (positiveWords.some((w) => t.includes(w))) {
      analysis.positive++;
    } else if (negativeWords.some((w) => t.includes(w))) {
      analysis.negative++;
    }
  }
  return analysis;
}

// Version endpoint to let client detect restart/updates
app.get("/version", (req, res) => {
  res.json({
    serverVersion,
    serverStartAt,
    now: new Date().toISOString(),
  });
});

// Health / debug endpoint
app.get("/test", (req, res) => {
  res.send("✅ Backend updated — " + new Date().toLocaleString());
});

// Main: fetch comments route
app.post("/api/comments", async (req, res) => {
  const { videoId } = req.body || {};
  if (!videoId) {
    return res.status(400).json({ error: "videoId is required" });
  }

  // First check memory cache
  try {
    // 1) Check Supabase cache (if configured)
    const cacheTTLms = 1000 * 60 * 30; // 30 minutes cache
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from("comments_cache")
          .select("*")
          .eq("video_id", videoId)
          .limit(1)
          .order("fetched_at", { ascending: false });
        if (error) throw error;
        if (data && data.length > 0) {
          const row = data[0];
          const age = Date.now() - new Date(row.fetched_at).getTime();
          if (age < cacheTTLms) {
            console.log(`🔁 Returning cached comments from Supabase for ${videoId}`);
            return res.json({ cached: true, comments: row.comments || [], analysis: row.analysis || { positive: 0, negative: 0, question: 0 } });
          }
        }
      } catch (err) {
        console.warn("⚠️ Supabase cache check failed:", err.message);
        // continue to in-memory check / fetch
      }
    }

    // 2) Check in-memory cache
    const mem = memoryCache.get(videoId);
    if (mem && Date.now() - mem.fetchedAt < 1000 * 60 * 30) {
      console.log(`🔁 Returning cached comments from memory for ${videoId}`);
      return res.json({ cached: true, comments: mem.comments, analysis: mem.analysis });
    }
  } catch (err) {
    console.warn("⚠️ Cache error (non-fatal):", err.message);
  }

  // 3) Fetch from YouTube API
  try {
    const API_KEY = process.env.YOUTUBE_API_KEY;
    if (!API_KEY) {
      throw new Error("YOUTUBE_API_KEY missing. Please add your YouTube API key in environment variables (Replit Secrets).");
    }

    // We'll fetch first page up to 100 top-level comments. For full pagination you'd loop using nextPageToken.
    const url = `https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=${encodeURIComponent(videoId)}&maxResults=100&textFormat=plainText&key=${API_KEY}`;

    const data = await fetchWithRetries(url, {}, 2);

    const items = data.items || [];
    const comments = items.map((it) => {
      const s = it.snippet?.topLevelComment?.snippet || {};
      return {
        author: s.authorDisplayName || "Unknown",
        text: s.textDisplay || "",
        publishedAt: s.publishedAt || null,
      };
    });

    const analysis = analyzeComments(comments);

    // Save to memory cache
    memoryCache.set(videoId, { fetchedAt: Date.now(), comments, analysis });

    // Try to upsert to Supabase (non-fatal if fails)
    if (supabase) {
      try {
        // Ensure table 'comments_cache' exists in your Supabase DB with columns:
        // video_id text primary key (or unique), comments jsonb, analysis jsonb, fetched_at timestamptz
        // We'll do an insert; if duplicate key error occurs, fallback to update
        const insertRow = {
          video_id: videoId,
          comments: comments,
          analysis: analysis,
          fetched_at: new Date().toISOString(),
        };
        const { error } = await supabase.from("comments_cache").insert(insertRow).select();
        if (error) {
          // try update
          const { error: err2 } = await supabase.from("comments_cache").update(insertRow).eq("video_id", videoId);
          if (err2) console.warn("⚠️ Supabase upsert failed:", err2.message);
        }
      } catch (err) {
        console.warn("⚠️ Supabase save failed:", err.message);
      }
    }

    return res.json({ cached: false, comments, analysis });
  } catch (err) {
    // On failure: try to return memcached result if exists
    const mem = memoryCache.get(videoId);
    if (mem) {
      console.warn("⚠️ YouTube fetch failed, returning memory cache:", err.message);
      return res.json({ cached: true, comments: mem.comments, analysis: mem.analysis, warning: "YouTube fetch failed, returned cached data", error: err.message });
    }

    console.error("❌ Fetch comments failed:", err.message);
    return res.status(500).json({ error: "Failed to fetch comments: " + err.message });
  }
});

// Static serve index.html from /public/index.html

app.listen(PORT, () => {
  serverVersion = new Date().toISOString(); // set fresh version at listen time
  console.log(`⚡ Comment Genie hybrid backend running on port ${PORT}`);
  console.log(`Server version: ${serverVersion}`);
});
